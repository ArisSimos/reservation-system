function method(params) {
    
}
