function hasP(params) {
    
}