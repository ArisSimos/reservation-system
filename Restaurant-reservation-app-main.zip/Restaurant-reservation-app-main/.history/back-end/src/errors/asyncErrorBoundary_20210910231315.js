function asyncErrorBoundary(delegate) {
    
}