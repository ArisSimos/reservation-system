function methodNotAllowed() {
    
}
