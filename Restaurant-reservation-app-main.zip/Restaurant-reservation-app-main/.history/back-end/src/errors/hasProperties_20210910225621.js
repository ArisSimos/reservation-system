function hasProperties(params) {
    
}