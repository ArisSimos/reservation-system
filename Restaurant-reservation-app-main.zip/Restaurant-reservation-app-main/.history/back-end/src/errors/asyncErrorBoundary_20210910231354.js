function asyncErrorBoundary(delegate, defaultStatus) {
    return(req,res,next) =>{
        
    }
}