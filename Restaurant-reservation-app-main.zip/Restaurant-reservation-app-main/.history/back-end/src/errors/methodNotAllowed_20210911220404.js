function methodNotAll(params) {
    
}
