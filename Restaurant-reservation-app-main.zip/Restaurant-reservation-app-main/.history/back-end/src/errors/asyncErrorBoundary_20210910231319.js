function asyncErrorBoundary(delegate, default) {
    
}