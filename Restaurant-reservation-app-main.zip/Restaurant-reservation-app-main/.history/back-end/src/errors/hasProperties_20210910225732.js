
function hasProperties(...properties) {
    return function (req,res,next) {
        const { data = {}} = req.body;

    }
}