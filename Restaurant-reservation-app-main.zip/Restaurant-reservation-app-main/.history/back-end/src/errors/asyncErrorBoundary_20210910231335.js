function asyncErrorBoundary(delegate, defaultStatus) {
    return()
}