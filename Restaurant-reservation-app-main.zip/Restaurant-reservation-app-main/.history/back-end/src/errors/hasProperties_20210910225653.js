function hasProperties(...properties) {
    return function (req) {
        
    }
}