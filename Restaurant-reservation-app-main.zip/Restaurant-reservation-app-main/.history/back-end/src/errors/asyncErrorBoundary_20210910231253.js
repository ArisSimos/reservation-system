function asy(params) {
    
}