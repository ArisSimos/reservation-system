function hasProperties(...properties) {
    return
}