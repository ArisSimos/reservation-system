/**
 * Check if the form has all the properties needed to create a new item(reservation or table)
 * @param  {propertie} properties 
 * @returns 
 */
function hasProperties(...properties) {
    return function (req,res,next) {
        const { data = {}} = req.body;

    }
}