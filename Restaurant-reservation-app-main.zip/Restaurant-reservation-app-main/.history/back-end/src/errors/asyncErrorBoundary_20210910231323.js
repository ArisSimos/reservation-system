function asyncErrorBoundary(delegate, defaultStatus) {
    
}