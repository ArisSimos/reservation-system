function methodNotAllowed(req,res,next) {
    next({
        stat
    })
}
