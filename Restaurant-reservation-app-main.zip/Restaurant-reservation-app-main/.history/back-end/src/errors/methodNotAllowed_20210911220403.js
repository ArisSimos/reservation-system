function methodNotAllo(params) {
    
}
