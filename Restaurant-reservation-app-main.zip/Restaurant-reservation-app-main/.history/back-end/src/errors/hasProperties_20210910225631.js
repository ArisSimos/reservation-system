function hasProperties(...properties) {
    
}