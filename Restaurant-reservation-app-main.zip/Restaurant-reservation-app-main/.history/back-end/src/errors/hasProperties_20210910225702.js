function hasProperties(...properties) {
    return function (req,res,next) {
        cons
    }
}