function asyncErrorBoundary(delegate, defaultStat) {
    
}