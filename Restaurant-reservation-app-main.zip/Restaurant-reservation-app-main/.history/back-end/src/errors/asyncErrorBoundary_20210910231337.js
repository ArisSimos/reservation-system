function asyncErrorBoundary(delegate, defaultStatus) {
    return(re)
}